# Moonflower Supper Club Website

A whimsical spring-inspired static website built for GitHub Pages.

## Files
- `index.html` — the main site
- `styles.css` — all styling

## How to host on GitHub Pages
1. Create a new GitHub repository.
2. Upload `index.html` and `styles.css` to the root of the repository.
3. In GitHub, go to **Settings** → **Pages**.
4. Under **Build and deployment**, choose:
   - **Source:** Deploy from a branch
   - **Branch:** `main` / `/root`
5. Save.
6. GitHub will give you a public Pages link after it deploys.

## Easy edits
Open `index.html` and change:
- club name
- next gathering date
- menu
- RSVP email link
- text sections

You can also swap the title tag and footer text to match your wife's preferred name for the club.
